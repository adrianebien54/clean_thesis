# Cross-resolution repeats: TEST-split MAE, mean ± std across same-seed runs

Every (net, resolution) cell repeated with IDENTICAL config and seed 3035;
spread = framework nondeterminism (cuDNN kernels, unseeded DataLoader workers).
800 epochs, best-val-MAE checkpoint per rep evaluated on the held-out TEST
split. CSRNet AdamW lr4e-5 bs1 | MobileCount AdamW lr1e-3 bs6 | AUG=none |
LOG_PARA anchored at 772x519. std is the sample std (ddof=1), omitted at n=1.

| Resolution | Pixels | n | CSRNet val MAE | CSRNet test MAE | CSRNet test MSE | n | MobileCount val MAE | MobileCount test MAE | MobileCount test MSE |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 49x33 | 1,617 | 5 | 7.1176 ± 0.6558 | 6.5508 ± 0.7822 | 7.8487 ± 0.6888 | 5 | 2.6204 ± 0.3954 | 2.7109 ± 0.4781 | 3.5835 ± 0.6699 |
| 97x65 | 6,305 | 5 | 1.0304 ± 0.0821 | 1.3951 ± 0.1307 | 2.3071 ± 0.2271 | 5 | 2.4706 ± 0.0798 | 2.5486 ± 0.2582 | 3.5427 ± 0.2902 |
| 193x130 | 25,090 | 5 | 0.5295 ± 0.0068 | 0.8986 ± 0.0462 | 1.8662 ± 0.1139 | 5 | 0.8156 ± 0.0626 | 0.9050 ± 0.0840 | 1.2359 ± 0.1309 |
| 386x260 | 100,360 | 5 | 0.2851 ± 0.0081 | 0.4720 ± 0.0054 | 0.9917 ± 0.0092 | 5 | 0.4292 ± 0.0309 | 0.4713 ± 0.0344 | 0.6579 ± 0.0413 |
| 772x519 | 400,668 | 5 | 0.1928 ± 0.0026 | 0.2787 ± 0.0122 | 0.6138 ± 0.0467 | 5 | 0.3914 ± 0.0468 | 0.4287 ± 0.0453 | 0.5825 ± 0.0423 |
| 1544x1038 | 1,602,672 | 5 | 0.1818 ± 0.0041 | 0.2382 ± 0.0025 | 0.4830 ± 0.0116 | 5 | 0.2859 ± 0.0463 | 0.3124 ± 0.0355 | 0.4441 ± 0.0385 |

Test split: 112 images per resolution.
