# Accuracy vs peak inference memory (same-seed repeat sweep, 800 epochs)

Test MAE is the mean +- 1 sample std over n=5 same-seed (3035) repeats
per cell. Peak memory is the batch-1 max_memory_allocated during one warmed-up
test_forward, reused from exp/combined_resolution/inference_memory.json: it depends only on the network and
the input shape, so it is identical across repeats of a cell.

| Resolution | CSRNet peak MB | CSRNet test MAE | MobileCount peak MB | MobileCount test MAE |
|---|---:|---:|---:|---:|
| 49x33 | 85.9 | 6.5508 +- 0.7822 | 13.4 | 2.7109 +- 0.4781 |
| 97x65 | 79.9 | 1.3951 +- 0.1307 | 13.9 | 2.5486 +- 0.2582 |
| 193x130 | 88.7 | 0.8986 +- 0.0462 | 16.2 | 0.9050 +- 0.0840 |
| 386x260 | 164.8 | 0.4720 +- 0.0054 | 25.7 | 0.4713 +- 0.0344 |
| 772x519 | 460.4 | 0.2787 +- 0.0122 | 60.6 | 0.4287 +- 0.0453 |
| 1544x1038 | 1648.8 | 0.2382 +- 0.0025 | 204.0 | 0.3124 +- 0.0355 |

Model weights: CSRNet 16.26 M params (63.8 MB), MobileCount 3.40 M params (13.1 MB).
