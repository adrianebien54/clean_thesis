# Cross-resolution repeats: VALIDATION MAE at the best epoch vs at the end of the budget

Every (net, resolution) cell repeated with IDENTICAL config and seed 3035;
spread = framework nondeterminism (cuDNN kernels, unseeded DataLoader workers).
Read from the logged val curves; end of budget = epoch 800.
Validation split only -- the repeats sweep pruned the final-epoch weights, so
no train-split counterpart can be computed from it (see
exp/combined_resolution/trainsplit_best_vs_last.json for the 1500-epoch
single run, which retained latest_state.pth).
std is the sample std (ddof=1), omitted at n=1.

| Resolution | Pixels | n | CSRNet best | CSRNet last | CSRNet last/best | n | MobileCount best | MobileCount last | MobileCount last/best |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 49x33 | 1,617 | 5 | 7.1176 ± 0.6558 | 13.4410 ± 0.6400 | 1.90 ± 0.16 | 5 | 2.6204 ± 0.3954 | 4.1492 ± 1.5266 | 1.56 ± 0.37 |
| 97x65 | 6,305 | 5 | 1.0304 ± 0.0821 | 1.5718 ± 0.0424 | 1.53 ± 0.10 | 5 | 2.4706 ± 0.0798 | 4.4863 ± 0.7500 | 1.82 ± 0.31 |
| 193x130 | 25,090 | 5 | 0.5295 ± 0.0068 | 0.5712 ± 0.0126 | 1.08 ± 0.02 | 5 | 0.8156 ± 0.0626 | 1.0386 ± 0.1427 | 1.28 ± 0.18 |
| 386x260 | 100,360 | 5 | 0.2851 ± 0.0081 | 0.3301 ± 0.0134 | 1.16 ± 0.02 | 5 | 0.4292 ± 0.0309 | 0.5480 ± 0.0913 | 1.28 ± 0.25 |
| 772x519 | 400,668 | 5 | 0.1928 ± 0.0026 | 0.2502 ± 0.0070 | 1.30 ± 0.04 | 5 | 0.3914 ± 0.0468 | 1.2935 ± 0.1118 | 3.34 ± 0.47 |
| 1544x1038 | 1,602,672 | 5 | 0.1818 ± 0.0041 | 0.2398 ± 0.0087 | 1.32 ± 0.06 | 5 | 0.2859 ± 0.0463 | 1.4913 ± 0.1489 | 5.34 ± 1.12 |
