# Paper augmentation schemes @ 386x260 — TEST-split MAE (Tenebrio, seed 3035)

Original (untuned) HPs: Adam, wd 1e-4, bs 6, step gamma=0.995/epoch, 1500 epochs;
LR 1e-5 (CSRNet) / 1e-4 (MobileCount); LOG_PARA anchored at 772x519
(CSRNet 25.05, MobileCount 638.73, identical across arms). Each cell = the
best-val-MAE epoch's checkpoint evaluated on the held-out 386x260 test split.

| Aug scheme | CSRNet val MAE | CSRNet test MAE | CSRNet test MSE | CSRNet ep | MobileCount val MAE | MobileCount test MAE | MobileCount test MSE | MobileCount ep |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| no augmentation | 3.5141 | 3.2795 | 4.5970 | 8 | 0.6052 | 0.7596 | 1.0417 | 150 |
| mc80 (online 80% crop) | 3.5132 | 3.0972 | 4.9548 | 14 | 0.6323 | 0.6180 | 0.7991 | 185 |
| csrnet9 (offline 18-patch) | 4.0742 | 3.5490 | 5.6467 | 640 | 0.6221 | 0.7004 | 0.9715 | 112 |

Test split: 112 full 386x260 images for every arm (csrnet9 patches are train-only).
