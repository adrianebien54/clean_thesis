# Batch-size sweep (new LOG_PARA, AdamW only) — consolidated final table

Tenebrio 386x260, seed 3035, 1500 ep. Each batch size runs at its
sqrt(bs/6)-scaled LR off the net's bs6 optimum. bs6 = new-LOG_PARA LR-grid anchor.
CSRNet lp25 (LOG_PARA 25.03), MobileCount lp639 (LOG_PARA 638.73).

## CSRNet (LOG_PARA 25.05)

| bs | optimizer | lr | MAE | MSE | source |
|----|-----------|----|-----|-----|--------|
| 1 | AdamW | 4.0e-05 | 0.2876 ✅ | 0.6013 | bs sweep |
| 2 | AdamW | 6.0e-05 | 0.2917 | 0.6080 | bs sweep |
| 4 | AdamW | 8.0e-05 | 0.3069 | 0.6093 | bs sweep |
| 6 | AdamW | 1.0e-04 | 0.3203 | 0.6271 | LR grid (anchor) |
| 8 | AdamW | 1.2e-04 | 0.3188 | 0.6116 | bs sweep |

**Best CSRNet: bs1 AdamW @ 4.0e-05 -> MAE 0.2876**

## MobileCount (LOG_PARA 638.73)

| bs | optimizer | lr | MAE | MSE | source |
|----|-----------|----|-----|-----|--------|
| 1 | AdamW | 4.0e-04 | 2.8458 | 4.3388 | bs sweep |
| 2 | AdamW | 6.0e-04 | 0.5433 | 0.7566 | bs sweep |
| 4 | AdamW | 8.0e-04 | 0.4360 | 0.6127 | bs sweep |
| 6 | AdamW | 1.0e-03 | 0.3850 ✅ | 0.5532 | LR grid (anchor) |
| 8 | AdamW | 1.2e-03 | 0.4603 | 0.6288 | bs sweep |

**Best MobileCount: bs6 AdamW @ 1.0e-03 -> MAE 0.3850**
