# Peak GPU memory of batch-1 inference (Tenebrio best-val checkpoints)

max_memory_allocated during one test_forward after warm-up (weights + input +
activation peak), measured on the checkpoints behind testset_table.md.

| Resolution | CSRNet peak MB | CSRNet test MAE | MobileCount peak MB | MobileCount test MAE |
|---|---:|---:|---:|---:|
| 49x33 | 85.9 | 5.4641 | 13.4 | 2.9202 |
| 97x65 | 79.9 | 1.3557 | 13.9 | 2.0015 |
| 193x130 | 88.7 | 0.8853 | 16.2 | 0.8952 |
| 386x260 | 164.8 | 0.4697 | 25.7 | 0.4332 |
| 772x519 | 460.4 | 0.2893 | 60.6 | 0.4708 |
| 1544x1038 | 1648.8 | 0.2328 | 204.0 | 0.3609 |

Model weights: CSRNet 16.26 M params (63.8 MB), MobileCount 3.40 M params (13.1 MB).
