# Best-combo val MAE across input resolutions (Tenebrio, seed 3035, AUG=none, 1500 ep)

CSRNet AdamW lr4e-5 bs1 | MobileCount AdamW lr1e-3 bs6 | LOG_PARA anchored at 772x519.
386x260 (the tuning resolution) is folded in from its original sweeps; all others
from bestcombo_resolutions_06-24_11-49.

| Resolution | Pixels | CSRNet MAE | CSRNet MSE | MobileCount MAE | MobileCount MSE |
|---|---:|---:|---:|---:|---:|
| 49x33 | 1,617 | 5.9635 | 6.7685 | 2.6813 | 3.4162 |
| 97x65 | 6,305 | 1.0255 | 1.3836 | 1.9126 | 2.6335 |
| 193x130 | 25,090 | 0.5341 | 0.9957 | 0.8614 | 1.1493 |
| 386x260 * | 100,360 | 0.2876 | 0.6013 | 0.3850 | 0.5532 |
| 772x519 | 400,668 | 0.1931 | 0.4501 | 0.4338 | 0.6089 |
| 1544x1038 | 1,602,672 | 0.1825 | 0.3577 | 0.4276 | 0.5644 |

\* 386x260 point: CSRNet from batchsize_logpara sweep, MobileCount from aa_final/mobilecount_logpara2550 (same best combo & AUG=none).
