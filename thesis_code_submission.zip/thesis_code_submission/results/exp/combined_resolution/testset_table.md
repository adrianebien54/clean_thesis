# Best-epoch TEST-split MAE across input resolutions (Tenebrio, seed 3035, AUG=none)

Each cell's best-*validation*-MAE checkpoint (the epoch reported in
resolution_table.md) evaluated on the held-out TEST split. CSRNet AdamW lr4e-5 bs1 |
MobileCount AdamW lr1e-3 bs6 | LOG_PARA anchored at 772x519. 386x260 checkpoints
from their original sweeps; all others from bestcombo_resolutions_06-24_11-49.

| Resolution | Pixels | CSRNet val MAE | CSRNet test MAE | CSRNet test MSE | MobileCount val MAE | MobileCount test MAE | MobileCount test MSE |
|---|---:|---:|---:|---:|---:|---:|---:|
| 49x33 | 1,617 | 5.9635 | 5.4641 | 6.2173 | 2.6813 | 2.9202 | 3.9632 |
| 97x65 | 6,305 | 1.0255 | 1.3557 | 2.4011 | 1.9126 | 2.0015 | 2.9471 |
| 193x130 | 25,090 | 0.5341 | 0.8853 | 1.8276 | 0.8614 | 0.8952 | 1.2515 |
| 386x260 * | 100,360 | 0.2876 | 0.4697 | 0.9729 | 0.3850 | 0.4332 | 0.6532 |
| 772x519 | 400,668 | 0.1931 | 0.2893 | 0.6827 | 0.4338 | 0.4708 | 0.6177 |
| 1544x1038 | 1,602,672 | 0.1825 | 0.2328 | 0.4788 | 0.4276 | 0.3609 | 0.5205 |

Test split: 112 images per resolution. \* 386x260 checkpoints from the batchsize_logpara (CSRNet) and mobilecount_logpara2550 (MobileCount) sweeps.
