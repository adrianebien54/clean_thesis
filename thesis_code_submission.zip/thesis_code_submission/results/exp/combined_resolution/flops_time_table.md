# FLOPs and batch-1 inference time (Tenebrio best-val checkpoints)

GMac via vendored ptflops (CPU forward, hooked modules only); time is the
mean of 100 synchronized GPU test_forward runs after 10 warm-up
runs with cudnn.benchmark, on the checkpoints behind testset_table.md.

| Resolution | CSRNet GMac | CSRNet ms/img | MobileCount GMac | MobileCount ms/img |
|---|---:|---:|---:|---:|
| 49x33 | 0.639 | 0.93 ± 0.00 | 0.024 | 1.26 ± 0.04 |
| 97x65 | 2.548 | 0.98 ± 0.00 | 0.074 | 1.22 ± 0.03 |
| 193x130 | 10.208 | 1.22 ± 0.00 | 0.243 | 1.24 ± 0.06 |
| 386x260 | 41.004 | 2.88 ± 0.01 | 0.871 | 1.24 ± 0.04 |
| 772x519 | 163.806 | 11.27 ± 0.01 | 3.300 | 1.76 ± 0.10 |
| 1544x1038 | 660.629 | 47.11 ± 0.06 | 12.864 | 5.64 ± 0.01 |

Params: CSRNet 16.26 M, MobileCount 3.40 M.
